<?php
if (!defined('ABSPATH')) exit;
?>
<div id="message" class="updated">
    <h4><?php _e('Thank you for updating to the latest version!', MPSL_TEXTDOMAIN); ?></h4>
</div>